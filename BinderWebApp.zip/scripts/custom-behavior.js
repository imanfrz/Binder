let genres = [];
let authors = [];
let selectedGenres = [];
let selectedAuthors = [];
let cleanedQueryResults = [];

const MAX_SEARCH_RESULTS_TO_SHOW = 10;

/********* GENRE PREFERENCE TAB *********/
function renderSelectedGenres(){
  let newHTML = "";

  /* Go through all selected genres and create buttons for them with an onclick event to remove them from the selection */
  for (let i = 0; i < selectedGenres.length; i++) {
    newHTML += `<button onclick="removeGenre(${i})">${selectedGenres[i]} &nbsp;&nbsp;&#9447;</button>`;
  }
  
  /* Insert into the document */
  document.getElementById("selected-genres").innerHTML = newHTML;
}

function selectGenre(genreToAdd) {
  /* Do not allow duplicates */
  if (!selectedGenres.includes(genreToAdd)) {
    selectedGenres.push(genreToAdd);
  }
  
  renderSelectedGenres();
}

function removeGenre(indexToRemove) {
  /* we used https://stackoverflow.com/questions/5767325/how-can-i-remove-a-specific-item-from-an-array to figure out how to remove an item at a specific index of an array */
  selectedGenres.splice(indexToRemove, 1);
  
  renderSelectedGenres();
}

/* Authors */
function renderSelectedAuthors(){
  let newHTML = "";

  /* Go through all selected genres and create buttons for them with an onclick event to remove them from the selection */
  for (let i = 0; i < selectedAuthors.length; i++) {
    newHTML += `<button onclick="removeAuthor(${i})">${selectedAuthors[i]} &nbsp;&nbsp;&#9447;</button>`;
  }
  
  /* Insert into the document */
  document.getElementById("selected-authors").innerHTML = newHTML;
}

function selectAuthor(authorToAdd) {
  /* Do not allow duplicates */
  if (!selectedAuthors.includes(authorToAdd)) {
    selectedAuthors.push(authorToAdd);
  }
  
  renderSelectedAuthors();
}

function removeAuthor(indexToRemove) {
  /* we used https://stackoverflow.com/questions/5767325/how-can-i-remove-a-specific-item-from-an-array to figure out how to remove an item at a specific index of an array */
  selectedAuthors.splice(indexToRemove, 1);
  
  renderSelectedAuthors();
}


/******* SPARQL QUERY IMPLEMENTATIONS *******/
angular.module('KRRclass', [ 'chart.js']).controller('MainCtrl', ['$scope','$http', mainCtrl]);

function mainCtrl($scope, $http){
  /* Get genres for the autocomplete genre search input field on page load */
	$scope.startMyAwesomeApp = function(){
		$scope.mySparqlEndpoint = "http://localhost:7200/repositories/Binder" ;
		
		$scope.genresQuery = encodeURI(`PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
PREFIX bd: <http://www.example.com/binder/>

select ?genreLabel where { 
	?genre a bd:Genre .
    
    service <https://www.dbpedia.org/sparql> {
        ?genre rdfs:label ?genreLabel .
        FILTER(LANGMATCHES(LANG(?genreLabel), 'en'))
    }
}`).replace(/#/g, '%23');

		$http( {
			method: "GET",
			url : $scope.mySparqlEndpoint + "?query=" + $scope.genresQuery,
			headers : {'Accept':'application/sparql-results+json', 'Content-Type':'application/sparql-results+json'}
		} )
		.success(function(data, status ) {
			/* Insert all results into the global variable genres */
			angular.forEach(data.results.bindings, function(val) {
        genres.push(val.genreLabel.value);
			});

      /* Sort the genres for better autocomplete experience */
      genres.sort();
	  
      
      /* If the call was successful, remove the warning box => GraphDB is working correctly */
      document.getElementById("warning-box").style.display = "none";

      /* Remove the cover disabling the preference input fields */
      document.getElementById("preference-input-cover").style.display = "none";
		})
		.error(function(error ){
			console.log('Error running the input query!'+error);
		});
		
		
		/* Authors Query */
		$scope.authorsQuery = encodeURI(`PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
PREFIX bd: <http://www.example.com/binder/>

select distinct ?authorName where { 
    ?book bd:hasAuthor ?author .
    ?author rdfs:label ?authorName .
}`).replace(/#/g, '%23');

		$http( {
			method: "GET",
			url : $scope.mySparqlEndpoint + "?query=" + $scope.authorsQuery,
			headers : {'Accept':'application/sparql-results+json', 'Content-Type':'application/sparql-results+json'}
		} )
		.success(function(data, status ) {
			/* Insert all results into the global variable authors */
			angular.forEach(data.results.bindings, function(val) {
        authors.push(val.authorName.value);
			});

      /* Sort the authors for better autocomplete experience */
      authors.sort();
	  
      
      /* If the call was successful, remove the warning box => GraphDB is working correctly */
      /*document.getElementById("warning-box").style.display = "none"; */

      /* Remove the cover disabling the preference input fields */
      /*document.getElementById("preference-input-cover").style.display = "none"; */
		})
		.error(function(error ){
			console.log('Error running the input query!'+error);
		});

	};

  $scope.startMyAwesomeApp();
  
  /* When user presses search, get book recommendations */
  $scope.getRecommendations = function(){    

    /* Start loading animation using https://loading.io/css/ customised to look like books */
    renderLoadingAnimation();
    
    /* Store user input in a single structure */
    let userInput = {
      wantsToListen: false,
      wantsToRead: false,
      
      shortReading: false,
      mediumReading: false,
      longReading: false,
      
      genres: [],  
	  authors: [],
    
      oneStar: false,
      twoStar: false,
      threeStar: false,
      fourStar: false,
      fiveStar: false
    };

    /* Get user input from the document */
    // Read and/or listen
    userInput["wantsToRead"] = document.getElementById('userInputRead').checked;
    userInput["wantsToListen"] = document.getElementById('userInputListen').checked;

    //Reading Length
    userInput["shortReading"] = document.getElementById('userInputShort').checked;
    userInput["mediumReading"] = document.getElementById('userInputMedium').checked;
    userInput["longReading"] = document.getElementById('userInputLong').checked;

    // Get genres directly from selectedGenres array
    userInput["genres"] = selectedGenres;
	
	 // Get authors directly from selectedGenres array
    userInput["authors"] = selectedAuthors;

    //Ratings
    userInput["oneStar"] = document.getElementById('userInputOneStar').checked;
    userInput["twoStar"] = document.getElementById('userInputTwoStar').checked;
    userInput["threeStar"] = document.getElementById('userInputThreeStar').checked;
    userInput["fourStar"] = document.getElementById('userInputFourStar').checked;
    userInput["fiveStar"] = document.getElementById('userInputFiveStar').checked;

    /* Output the userInput to console for debugging and evaluation */
    console.log(userInput)

    /* Run the query */
		$scope.mySparqlEndpoint = "http://localhost:7200/repositories/Binder" ;
		
    /* Always included in the query */
		let query = `PREFIX spif: <http://spinrdf.org/spif#>
PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>
PREFIX dbo: <http://dbpedia.org/ontology/>
PREFIX bif: <http://www.openlinksw.com/schemas/bif#>
PREFIX dcterms: <http://purl.org/dc/terms/>
PREFIX dbr: <http://dbpedia.org/resource/>
PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
PREFIX bd: <http://www.example.com/binder/>

SELECT DISTINCT ?bookTitle ?authorLabel ?length ?genreLabel ?format ?abstract ?rating ?publisherLabel WHERE {

	?book a bd:Book .
	?book bd:hasTitle ?bookTitle .
	?book bd:hasPageCount ?length .
	?book bd:hasRating ?rating .
	?book bd:hasAuthor ?author .
	?author rdfs:label ?authorLabel.

    OPTIONAL {
        ?book bd:hasGenre ?genre .
        ?book bd:hasPublisher ?publisher .
        ?publisher rdfs:label ?publisherLabel .
        service <https://www.dbpedia.org/sparql> {
            ?genre rdfs:label ?genreLabel .
			?book dbo:abstract ?abstract .
        }
    }
	FILTER(LANG(?genreLabel) = "en")
	FILTER(LANG(?abstract) = "en")`

    /* If genres selected, insert a new filter. */
    if (userInput["genres"].length > 0) {
      query += `FILTER (`;
      
      for (let i = 0; i < userInput["genres"].length; i++) {
        query += `?genre = URI("http://dbpedia.org/resource/${userInput["genres"][i].replace(/ /g,"_")}")`; /* https://stackoverflow.com/questions/441018/replacing-spaces-with-underscores-in-javascript */

        if (i == userInput["genres"].length - 1) {
          query += `)`; /* If last element */
        } else {
          query += `||`; /* If not last element, add "or" */
        }
      }
    }
	
	/* If authors selected, insert a new filter. */
    if (userInput["authors"].length > 0) {
      query += `FILTER (`;
      
      for (let i = 0; i < userInput["authors"].length; i++) {
	  query += `?authorLabel ="${userInput["authors"][i]}"`; /* https://stackoverflow.com/questions/441018/replacing-spaces-with-underscores-in-javascript */

        if (i == userInput["authors"].length - 1) {
          query += `)`; /* If last element */
        } else {
          query += `||`; /* If not last element, add "or" */
        }
      }
    }
    
    // FORMAT FILTER
    // TODO: - create classes "Reading_format" "Audio_format" 
    //       - class restrictions (so audio and read books are in it)
    if (userInput["wantsToRead"] && userInput["wantsToListen"]) {
      query += `\n{?book dcterms:format bd:Reading} UNION {?book dcterms:format bd:Audio} `;
    }else if(userInput["wantsToRead"]) {
      query += ` ?book dcterms:format bd:Reading `;
    }else if(userInput["wantsToListen"]) {
      query += ` ?book dcterms:format bd:Audio `;
    }
    
    // LENGTH FILTER
    let lengthList = []
    
    if (userInput["shortReading"]){
      lengthList.push(`bd:ShortBook`)
    }
    
    if (userInput["mediumReading"]){
      lengthList.push(`bd:MediumBook`)
    }

    if (userInput["longReading"]){
      lengthList.push(`bd:LongBook`)
    }

    if (lengthList.length > 0) {
		for (let i = 0; i < lengthList.length; i++) {
		  if (i == 0) {
			  query += `{?book a ` + lengthList[0] +`} `
		  }
		  else {
				query += `UNION{?book a ` + lengthList[i] +`}`
			}
	}
	}
    
    
    // RATING FILTER
    
    let ratingList = []
    
    if (userInput["oneStar"]){
      ratingList.push(`bd:OneStarBook`)
    }
    
    if (userInput["twoStar"]){
      ratingList.push(`bd:TwoStarBook`)
    }

    if (userInput["threeStar"]){
      ratingList.push(`bd:ThreeStarBook`)
    }
    
     if (userInput["fourStar"]){
      ratingList.push(`bd:FourStarBook`)
    }

     if (userInput["fiveStar"]){
      ratingList.push(`bd:FiveStarBook`)
    }
    
    if (ratingList.length > 0) {
		for (let i = 0; i < ratingList.length; i++) {
		  if (i == 0) {
			  query += `{?book a ` + ratingList[0] +`} `
		  }
		  else {
				query += `UNION{?book a ` + ratingList[i] +`}`
			}
	}
	}
    
    /* Always add to finish query */
    query += `}
ORDER BY DESC (?rating)`
    
    console.log(query)
    $scope.genresQuery = encodeURI(query).replace(/#/g, '%23');

		$http( {
			method: "GET",
			url : $scope.mySparqlEndpoint + "?query=" + $scope.genresQuery,
			headers : {'Accept':'application/sparql-results+json', 'Content-Type':'application/sparql-results+json'}
		} )
		.success(function(data, status ) {
			/* Query was successful, get rough results */
      let queryResults = [];
			
			angular.forEach(data.results.bindings, function(val) {
        queryResults.push({
          title: val.bookTitle ? val.bookTitle.value : null,
          author: val.authorLabel ? val.authorLabel.value : null,
          length: val.length ? val.length.value : null,
          genres: val.genreLabel ? val.genreLabel.value : null,
          format: val.format? val.format.value : null,
          abstract: val.abstract ? val.abstract.value : null,
          rating: val.rating ? val.rating.value : null,
        });
			});

      /* For debugging */
      console.log(queryResults);
      
      /* Clean up data duplicates from the results using method outlined in https://codeburst.io/javascript-array-distinct-5edc93501dc4
      Add the results to a emptied global variable */
      cleanedQueryResults = [];
      let map = new Map();
      for (let item of queryResults) {
          if(!map.has(item.title)){
              map.set(item.title, true);
              cleanedQueryResults.push(item);
          }
      }
      
      console.log(cleanedQueryResults)
      
      /* Show results in the recommendations screen */
      moveToRecommendationsScreen();
		})
		.error(function(error ){
			console.log('Error running the input query!'+error);
		});

	};

}

/***** Book recommendations results screen implementations *****/
function renderLoadingAnimation() {
  document.getElementById("user-preference-input-screen").style.display = "none";
  document.getElementById("recommendation-results-screen").style.display = "block";
  window.scrollTo(0, 0);
  
  document.getElementById('addBooksHere').innerHTML = `<div class="lds-ellipsis"><div></div><div></div><div></div><div></div></div>`;
  console.log("render loading animation")
}

function renderNoResultsScreen() {
  document.getElementById('addBooksHere').innerHTML = `<div class="text-container">Oopsie! No books found. Try searching with other criteria, leave some selections blank, or add more genres!</div>`;
}

function renderRecommendedBooks(selectedBookIndex) {
  let addHtml = "";
  
  /* Only show maximum of MAX_SEARCH_RESULTS_TO_SHOW search results */
  let numberOfSearchResults = cleanedQueryResults.length;

  let numberOfSearchResultsToShow = 0;
  if (numberOfSearchResults > MAX_SEARCH_RESULTS_TO_SHOW) {
    numberOfSearchResultsToShow = MAX_SEARCH_RESULTS_TO_SHOW;
  } else {
    numberOfSearchResultsToShow = numberOfSearchResults;
  }
  
  if (numberOfSearchResultsToShow == 0){
    /* No results, render no results screen and return from function */
    renderNoResultsScreen();
    return;
  }
  
  /* Render selected book characteristics */

  let stars = "";
  console.log(cleanedQueryResults[selectedBookIndex]["rating"]);
  for (let i = 0; i < Math.round(cleanedQueryResults[selectedBookIndex]["rating"]); i++) {
    stars += "&#9733;";
  }
  console.log(stars);

  addHtml += `<div class="selected-book-container" itemscope itemtype="https://schema.org/Book">
          <h2 class="selected-book-title" itemprop="name">${cleanedQueryResults[selectedBookIndex]["title"]}</h2>
          <div class="selected-book-cover" itemprop="name">${cleanedQueryResults[selectedBookIndex]["title"]}<div class="book-rating-stars">${stars}</div></div>
          <div class="selected-book-information">
            <table>`

  // Author
  if (cleanedQueryResults[selectedBookIndex]["author"]) {
    addHtml += `<tr>
      <th>Author</th>
      <td itemprop="author">${cleanedQueryResults[selectedBookIndex]["author"]}</td>
    </tr>`
  }

  // Length
  if(cleanedQueryResults[selectedBookIndex]["length"]){
  addHtml += `<tr>
    <th>Length</th>
    <td><span itemprop="numberOfPages">${cleanedQueryResults[selectedBookIndex]["length"]}</span> pages</td>
  </tr>`
  }

  // Genres
  if(cleanedQueryResults[selectedBookIndex]["genres"]){
  addHtml += `<tr>
    <th>Genre</th>
    <td itemprop="genre">${cleanedQueryResults[selectedBookIndex]["genres"]}</td>
  </tr>`
  }

  //Format
  if(cleanedQueryResults[selectedBookIndex]["format"]) {
  addHtml += `<tr>
    <th>Available as</th>
    <td>${cleanedQueryResults[selectedBookIndex]["format"]}</td>
  </tr>`
  }

  // Abstract
  if(cleanedQueryResults[selectedBookIndex]["abstract"]) {
    addHtml += `<tr>
      <th>Abstract</th>
      <td itemprop="abstract">${cleanedQueryResults[selectedBookIndex]["abstract"]}</td>
    </tr>`
  }

  let amazonLink = cleanedQueryResults[selectedBookIndex]["title"].replace(/ /g, "+").replace(":", "+");

  addHtml += `</table>
        <button onclick="window.location.href = 'https://www.amazon.com/s?k=${amazonLink}'">Buy on Amazon</button>
      </div>
    </div>`
  
  if (cleanedQueryResults.length > 1) {
    addHtml += `<div id="recommended-books">`;
    
    for (let i = 0; i < numberOfSearchResultsToShow; i++) {
      addHtml += `<div class="recommended-book" onclick="renderRecommendedBooks(${i})">${cleanedQueryResults[i]["title"]}</div>`
    }
    
    addHtml += `</div>`;
  }
  
  document.getElementById('addBooksHere').innerHTML = addHtml;
}

/* Navigation */
function moveToRecommendationsScreen() {
  renderRecommendedBooks(0);

  /* Move to recommendations screen */
  document.getElementById("user-preference-input-screen").style.display = "none";
  document.getElementById("recommendation-results-screen").style.display = "block";
  window.scrollTo(0, 0); // Go back to the top of the page

}

function backToUserInput() {
  document.getElementById("user-preference-input-screen").style.display = "block";
  document.getElementById("recommendation-results-screen").style.display = "none";
}

/* We implemented the autocomplete function using https://www.w3schools.com/howto/howto_js_autocomplete.asp with minor changes */
function autocomplete1(inp, arr) {
  /*the autocomplete function takes two arguments,
  the text field element and an array of possible autocompleted values:*/
  var currentFocus;
  /*execute a function when someone writes in the text field:*/
  inp.addEventListener("input", function(e) {
      var a, b, i, val = this.value;
      /*close any already open lists of autocompleted values*/
      closeAllLists();
      if (!val) { return false;}
      currentFocus = -1;
      /*create a DIV element that will contain the items (values):*/
      a = document.createElement("DIV");
      a.setAttribute("id", this.id + "autocomplete-list");
      a.setAttribute("class", "autocomplete-items");
      /*append the DIV element as a child of the autocomplete container:*/
      this.parentNode.appendChild(a);
      /*for each item in the array...*/
      for (i = 0; i < arr.length; i++) {
        /*check if the item starts with the same letters as the text field value:*/
        if (arr[i].substr(0, val.length).toUpperCase() == val.toUpperCase()) {
          /*create a DIV element for each matching element:*/
          b = document.createElement("DIV");
          /*make the matching letters bold:*/
          b.innerHTML = "<strong>" + arr[i].substr(0, val.length) + "</strong>";
          b.innerHTML += arr[i].substr(val.length);
          /*insert a input field that will hold the current array item's value:*/
          b.innerHTML += "<input type='hidden' value='" + arr[i] + "'>";
          /*execute a function when someone clicks on the item value (DIV element):*/
              b.addEventListener("click", function(e) {
              /*insert the value for the autocomplete text field:*/
              inp.value = "";
              selectGenre(this.getElementsByTagName("input")[0].value);
              
              /*close the list of autocompleted values,
              (or any other open lists of autocompleted values:*/
              closeAllLists();
          });
          a.appendChild(b);
        }
      }
  });
  /*execute a function presses a key on the keyboard:*/
  inp.addEventListener("keydown", function(e) {
      var x = document.getElementById(this.id + "autocomplete-list");
      if (x) x = x.getElementsByTagName("div");
      if (e.keyCode == 40) {
        /*If the arrow DOWN key is pressed,
        increase the currentFocus variable:*/
        currentFocus++;
        /*and and make the current item more visible:*/
        addActive(x);
      } else if (e.keyCode == 38) { //up
        /*If the arrow UP key is pressed,
        decrease the currentFocus variable:*/
        currentFocus--;
        /*and and make the current item more visible:*/
        addActive(x);
      } else if (e.keyCode == 13) {
        /*If the ENTER key is pressed, prevent the form from being submitted,*/
        e.preventDefault();
        if (currentFocus > -1) {
          /*and simulate a click on the "active" item:*/
          if (x) x[currentFocus].click();
        }
      }
  });
  function addActive(x) {
    /*a function to classify an item as "active":*/
    if (!x) return false;
    /*start by removing the "active" class on all items:*/
    removeActive(x);
    if (currentFocus >= x.length) currentFocus = 0;
    if (currentFocus < 0) currentFocus = (x.length - 1);
    /*add class "autocomplete-active":*/
    x[currentFocus].classList.add("autocomplete-active");
  }
  function removeActive(x) {
    /*a function to remove the "active" class from all autocomplete items:*/
    for (var i = 0; i < x.length; i++) {
      x[i].classList.remove("autocomplete-active");
    }
  }
  function closeAllLists(elmnt) {
    /*close all autocomplete lists in the document,
    except the one passed as an argument:*/
    var x = document.getElementsByClassName("autocomplete-items");
    for (var i = 0; i < x.length; i++) {
      if (elmnt != x[i] && elmnt != inp) {
      x[i].parentNode.removeChild(x[i]);
    }
  }
}
/*execute a function when someone clicks in the document:*/
document.addEventListener("click", function (e) {
    closeAllLists(e.target);
});
}

function autocomplete2(inp, arr) {
  /*the autocomplete function takes two arguments,
  the text field element and an array of possible autocompleted values:*/
  var currentFocus;
  /*execute a function when someone writes in the text field:*/
  inp.addEventListener("input", function(e) {
      var a, b, i, val = this.value;
      /*close any already open lists of autocompleted values*/
      closeAllLists();
      if (!val) { return false;}
      currentFocus = -1;
      /*create a DIV element that will contain the items (values):*/
      a = document.createElement("DIV");
      a.setAttribute("id", this.id + "autocomplete-list2");
      a.setAttribute("class", "autocomplete-items");
      /*append the DIV element as a child of the autocomplete container:*/
      this.parentNode.appendChild(a);
      /*for each item in the array...*/
      for (i = 0; i < arr.length; i++) {
        /*check if the item starts with the same letters as the text field value:*/
        if (arr[i].substr(0, val.length).toUpperCase() == val.toUpperCase()) {
          /*create a DIV element for each matching element:*/
          b = document.createElement("DIV");
          /*make the matching letters bold:*/
          b.innerHTML = "<strong>" + arr[i].substr(0, val.length) + "</strong>";
          b.innerHTML += arr[i].substr(val.length);
          /*insert a input field that will hold the current array item's value:*/
          b.innerHTML += "<input type='hidden' value='" + arr[i] + "'>";
          /*execute a function when someone clicks on the item value (DIV element):*/
              b.addEventListener("click", function(e) {
              /*insert the value for the autocomplete text field:*/
              inp.value = "";
              selectAuthor(this.getElementsByTagName("input")[0].value);
              
              /*close the list of autocompleted values,
              (or any other open lists of autocompleted values:*/
              closeAllLists();
          });
          a.appendChild(b);
        }
      }
  });
  /*execute a function presses a key on the keyboard:*/
  inp.addEventListener("keydown", function(e) {
      var x = document.getElementById(this.id + "autocomplete-list2");
      if (x) x = x.getElementsByTagName("div");
      if (e.keyCode == 40) {
        /*If the arrow DOWN key is pressed,
        increase the currentFocus variable:*/
        currentFocus++;
        /*and and make the current item more visible:*/
        addActive(x);
      } else if (e.keyCode == 38) { //up
        /*If the arrow UP key is pressed,
        decrease the currentFocus variable:*/
        currentFocus--;
        /*and and make the current item more visible:*/
        addActive(x);
      } else if (e.keyCode == 13) {
        /*If the ENTER key is pressed, prevent the form from being submitted,*/
        e.preventDefault();
        if (currentFocus > -1) {
          /*and simulate a click on the "active" item:*/
          if (x) x[currentFocus].click();
        }
      }
  });
  function addActive(x) {
    /*a function to classify an item as "active":*/
    if (!x) return false;
    /*start by removing the "active" class on all items:*/
    removeActive(x);
    if (currentFocus >= x.length) currentFocus = 0;
    if (currentFocus < 0) currentFocus = (x.length - 1);
    /*add class "autocomplete-active":*/
    x[currentFocus].classList.add("autocomplete-active");
  }
  function removeActive(x) {
    /*a function to remove the "active" class from all autocomplete items:*/
    for (var i = 0; i < x.length; i++) {
      x[i].classList.remove("autocomplete-active");
    }
  }
  function closeAllLists(elmnt) {
    /*close all autocomplete lists in the document,
    except the one passed as an argument:*/
    var x = document.getElementsByClassName("autocomplete-items");
    for (var i = 0; i < x.length; i++) {
      if (elmnt != x[i] && elmnt != inp) {
      x[i].parentNode.removeChild(x[i]);
    }
  }
}
/*execute a function when someone clicks in the document:*/
document.addEventListener("click", function (e) {
    closeAllLists(e.target);
});
}