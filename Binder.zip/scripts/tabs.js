/* Preference input screen tabbed navigation */
let DEFAULT_TAB = "format";
let tabElements = ["format", "length", "genre", "rating", "author"];

function hideAllBut(selectedTab) {
  /* First, hide all tabs */
  for (let i = 0; i < tabElements.length; i++) {
    /* Get the tab element and set it to hidden */
    let tabElementInDocument = document.getElementById(tabElements[i] + "-tab");
    tabElementInDocument.style.display = "none";

    /* Get the navigation link for that tab element and remove any class selected */
    let tabLinkElementInDocument = document.getElementById(tabElements[i] + "-link");
    tabLinkElementInDocument.classList.remove("selected");
  }
  
  /* Set only selected tab as visible */
  document.getElementById(selectedTab + "-tab").style.display = "block";
  
  /* Set only the link for the selected tab as selected */
  document.getElementById(selectedTab + "-link").classList.add("selected");
}

/* When loading the document, set  */
hideAllBut(DEFAULT_TAB)